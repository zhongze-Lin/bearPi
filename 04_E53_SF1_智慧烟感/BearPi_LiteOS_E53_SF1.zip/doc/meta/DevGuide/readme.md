Pictures for developer guide.
