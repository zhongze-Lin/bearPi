
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'STM32L431RC_BearPiADC_DMA' 
 * Target:  'STM32L431RC_BearPiADC_DMA' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32l4xx.h"


#endif /* RTE_COMPONENTS_H */
